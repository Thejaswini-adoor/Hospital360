package com.rs.rmk.btl_ltnc.security;

public enum Role {
    ADMIN,
    USER,
}
