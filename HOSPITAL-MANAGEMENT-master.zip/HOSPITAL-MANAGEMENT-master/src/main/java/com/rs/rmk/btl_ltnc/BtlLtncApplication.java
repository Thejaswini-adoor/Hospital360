package com.rs.rmk.btl_ltnc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtlLtncApplication {

    public static void main(String[] args) {
        SpringApplication.run(BtlLtncApplication.class, args);
    }
}
