<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Hướng dẫn chạy dự án từ code:</h1>
    <ul>
    <li>B1: Tải IntelliJ IDEA </li>
    <li>B2: Clone dự án từ github về IntelliJ IDEA: <br>
        <h4 style= "margin-left: 5%">Clone dự án tại đây:
        <a href="https://github.com/RavenTheshadow/BTL_LTNC.gits">https://github.com/RavenTheshadow/BTL_LTNC.gits </a>
        </h4>
    </li>
    <li>
        B3: Vào thư mục: <a>src/main/java/com/rs/rmk/btl_ltnc/BtlLtncApplication.java</a> <br>
    </li>
    <li>
        B4: Chọn phiên bản java để chạy.
        <h4 style="color: red; margin-left: 5%">Yêu cầu: Java Version 21.</h4>
    </li>
    <li>
        B5: Tải lại dự án, nhấn biểu tượng hình tam giác hoặc hình con bọ để build dự án.
    </li>
    <li>
        B6: Mở đường dẫn: <a link ="http://localhost:8080/">http://localhost:8080/</a> Để chạy dự án.
    </li>
    </ul>

[//]: # (    <h1>)

[//]: # (        Hướng dẫn chạy dự án từ dự án đóng gói. )

[//]: # (    </h1>)

[//]: # (    <ul>)

[//]: # (    <li>)

[//]: # (        B1: Truy cập đường dẫn: <a link= "https://drive.google.com/file/d/1O93AxMDRX8lD_MrXBwxHZ-x7ezzfRtAV/view?usp=sharing">https://drive.google.com/file/d/1O93AxMDRX8lD_MrXBwxHZ-x7ezzfRtAV/view?usp=sharing</a>)

[//]: # (    </li>)

[//]: # (    <li>)

[//]: # (        B2: Tải file RAR xuống.)

[//]: # (    <li>)

[//]: # (        B3: Mở terminal và di chuyển tới thư mục chứa dự án.)

[//]: # (    </li>)

[//]: # (    <li>)

[//]: # (        B4: Gõ lệnh java -jar BTL_LTNC.jar)

[//]: # (    </li>)

[//]: # (    <li>)

[//]: # (        B5: Mở đường dẫn: <a link ="http://localhost:8080/">http://localhost:8080/</a> Để chạy dự án.)

[//]: # (    </li>)

[//]: # (    </ul>)
</body>
</html>
